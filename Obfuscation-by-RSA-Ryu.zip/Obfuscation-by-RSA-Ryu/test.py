import obfuscation
import deobfuscation

# 주석주석주석주석
if __name__ == '__main__':
    user_name = obfuscation.encrypt('soft_sec')
    user_id = obfuscation.encrypt('12345678')
    print('user_name : ' + user_name)
    print('user_id : ' + user_id)